#include <stdio.h>
#include <stdlib.h>

#define STACK_SIZE 3

typedef struct Node {
    int data;
    struct Node *next;
} Node;

typedef struct {
    Node *top;
    int size;
} Stack;

void push(Stack *stack, int data) {
    if (stack->size >= STACK_SIZE) {
        printf("Stack overflow\n");
        return;
    }
    Node *newNode = (Node *)malloc(sizeof(Node));
    newNode->data = data;
    newNode->next = stack->top;
    stack->top = newNode;
    stack->size++;
}

int pop(Stack *stack) {
    if (stack->top == NULL) {
        printf("Stack underflow\n");
        return -1;
    }
    Node *temp = stack->top;
    int data = temp->data;
    stack->top = stack->top->next;
    free(temp);
    stack->size--;
    return data;
}

int isPrime(int num) {
    if (num <= 1) return 0;
    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0) return 0;
    }
    return 1;
}

void findAndPushPrimes(Stack *stack, int sphenicNumber) {
    int count = 0;
    for (int i = 2; i <= sphenicNumber && count < STACK_SIZE; i++) {
        if (sphenicNumber % i == 0 && isPrime(i)) {
            push(stack, i);
            count++;
            sphenicNumber /= i;
        }
    }
    if (count != STACK_SIZE || sphenicNumber != 1) {
        printf("The number is not a sphenic number or has more than 3 prime factors.\n");
        while (stack->size > 0) {
            pop(stack);
        }
    }
}

void displayStack(Stack *stack) {
    Node *current = stack->top;
    while (current != NULL) {
        printf("%d ", current->data);
        current = current->next;
    }
    printf("\n");
}

int main() {
    Stack stack;
    stack.top = NULL;
    stack.size = 0;

    int sphenicNumber = 30; // Example sphenic number (2 * 3 * 5)
    findAndPushPrimes(&stack, sphenicNumber);
    displayStack(&stack); // Output: 5 3 2

    return 0;
}