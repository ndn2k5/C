/*
Write a program to enter a natural number n and find all sphenic numbers from 1 to n using
Recursion (combined with iteration if necessary).
Note: A sphenic number is a product of p*q*r where p, q, and r are three distinct prime numbers.
Example: 30 = 2 * 3* 5; 42 = 2*3*7; 66 = 2*3*11.
30, 42, 66, 70, 78, 102, 105, 110, 114, 130, 138, 154, 165, … are sphenic numbers.
 Calculate the complexity of your program (Best scenario, Worst scenario, Average). Justify your
answer. (2pts)
*/

#include <stdio.h>

// Recursive function to check if a number is prime
int is_prime(int num, int divisor) {
    if (num < 2) return 0;          // Numbers less than 2 are not prime
    if (divisor * divisor > num) return 1; // Divisor exceeds sqrt(num), number is prime
    if (num % divisor == 0) return 0; // Number is divisible by divisor, not prime
    return is_prime(num, divisor + 1); // Recursive call
}

// Function to check if a number is sphenic
int is_sphenic(int num) {
    int primes[3] = {0, 0, 0}; // Array to store prime factors
    int prime_count = 0;       // Count of distinct prime factors
    
    // Iterate through numbers to check prime factors
    for (int i = 2; i <= num; i++) {
        if (num % i == 0 && is_prime(i, 2)) {  // Check if i is a prime factor
            primes[prime_count++] = i;         // Store prime factor
            num /= i;                          // Divide the number by prime factor
            if (num % i == 0) return 0;        // If prime factor repeats, not sphenic
            if (prime_count > 3) return 0;     // More than 3 distinct primes, not sphenic
        }
    }
    return prime_count == 3; // Return true if exactly 3 distinct primes
}

// Recursive function to find all sphenic numbers from 1 to n
void find_sphenic(int n) {
    if (n == 1) return;        // Base case: no sphenic number less than 2
    find_sphenic(n - 1);       // Recursive call to check previous numbers
    if (is_sphenic(n)) {       // Check if current number is sphenic
        printf("%d ", n);      // Print if sphenic
    }
}

int main() {
    int n;
    printf("Enter a natural number n: ");
    scanf("%d", &n);
    
    printf("Sphenic numbers from 1 to %d are: ", n);
    find_sphenic(n);           // Find and print all sphenic numbers up to n
    printf("\n");
    
    return 0;
}
