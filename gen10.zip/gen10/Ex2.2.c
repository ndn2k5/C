#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct Node {
    int data;
    struct Node* next;
} Node;

typedef struct Stack {
    Node* top;
    int size;
} Stack;

void push(Stack* stack, int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->next = stack->top;
    stack->top = newNode;
    stack->size++;
}

bool isEmpty(Stack* stack) {
    return stack->top == NULL;
}

void pop(Stack* stack) {
    if (isEmpty(stack)) {
        printf("Stack Underflow\n");
        return;
    }
    Node* temp = stack->top;
    stack->top = stack->top->next;
    stack->size--;
    free(temp);
}

bool isPrime(int n) {
    if (n <= 1)
        return false;
    for (int i = 2; i * i <= n; i++)
        if (n % i == 0)
            return false;
    return true;
}

bool isSphenic(int n) {
    int count = 0;
    int factors[3] = {0, 0, 0};
    for (int i = 2; i * i <= n; i++) {
        while (n % i == 0) {
            factors[count++] = i;
            n /= i;
        }
    }
    if (n > 1)
        factors[count++] = n;

    return count == 3 && isPrime(factors[0]) && isPrime(factors[1]) && isPrime(factors[2]);
}

void findAndPushPrimes(Stack* stack, int n) {
    for (int i = 2; i <= n; i++) {
        if (isSphenic(i)) {
            int factorCount = 0;
            for (int j = 2; j * j <= i; j++) {
                while (i % j == 0) {
                    factorCount++;
                    i /= j;
                }
            }
            if (i > 1)
                factorCount++;

            if (factorCount == 3) {
                for (int k = 0; k < 3; k++) {
                    if (isPrime(factors[k]))
                        push(stack, factors[k]);
                }
            }
        }
    }
}

void display(Stack* stack) {
    Node* temp = stack->top;
    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("\n");
}

int main() {
    Stack* stack = (Stack*)malloc(sizeof(Stack));
    stack->top = NULL;
    stack->size = 0;

    int n = 100; // Change this value to find primes for a different range
    findAndPushPrimes(stack, n);

    printf("Prime numbers for sphenic numbers up to %d:\n", n);
    display(stack);

    while (!isEmpty(stack))
        pop(stack);

    free(stack);

    return 0;
}