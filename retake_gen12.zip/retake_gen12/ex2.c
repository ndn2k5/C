#include <stdio.h>

float estimate_pi(int number_of_loop, int current_loop, float current_value) {
    if (current_loop == number_of_loop) {
        return current_value;
    } else {
        // Calculate the next term in the series
        float term = 4.0 / (2 * current_loop + 1);
        
        // Alternate between adding and subtracting the term
        if (current_loop % 2 == 0) {
            current_value += term;
        } else {
            current_value -= term;
        }

        return estimate_pi(number_of_loop, current_loop + 1, current_value);
    }
}

int main() {
    int number_of_loop;
    printf("Enter the number of loop: ");
    scanf("%d", &number_of_loop);
    printf("The value of pi is: %.10f\n", estimate_pi(number_of_loop, 0, 0.0));
    return 0;
}
