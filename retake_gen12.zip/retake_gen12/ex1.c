#include <stdio.h>

double loop(int n, int i, double pi) {
    if (i == n) {
        return pi;
    } else if (i % 2 == 0) {
        pi -= 4.0 / (2.0 * i * (2.0 * i + 1.0));
    } else {
        pi += 4.0 / (2.0 * i * (2.0 * i + 1.0));
    }
    return loop(n, i + 1, pi);
}

int main() {
    int n;
    printf("How many loops: ");
    scanf("%d", &n);
    printf("Pi ~= %.10f\n", loop(n, 1, 3.0));
    return 0;
}
