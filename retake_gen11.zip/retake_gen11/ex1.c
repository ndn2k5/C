/*
Propose two recursive pseudo-code algorithms to count the number of odd and even digits of
N (one function for odd, one function for even). (2 pts)
 Implement the proposed algorithms in C/C++. (8pts)
 Calculate the complexity of your program (Best scenario, Worst scenario, Average). Justify
your answer. (2 pts)
*/

#include <stdio.h>

// Function to count odd digits
int count_odd_digits(int N) {
    if (N == 0) {
        return 0; // Base case: when N is 0
    }

    int last_digit = N % 10; // Get the last digit
    int count = count_odd_digits(N / 10); // Recursive call with the remaining digits

    // Check if the last digit is odd
    if (last_digit % 2 != 0) {
        return count + 1; // Increment count if it's odd
    } else {
        return count; // Return count as is if it's even
    }
}

// Function to count even digits
int count_even_digits(int N) {
    if (N == 0) {
        return 0; // Base case: when N is 0
    }

    int last_digit = N % 10; // Get the last digit
    int count = count_even_digits(N / 10); // Recursive call with the remaining digits

    // Check if the last digit is even
    if (last_digit % 2 == 0) {
        return count + 1; // Increment count if it's even
    } else {
        return count; // Return count as is if it's odd
    }
}

int main() {
    int number;
    printf("Enter a number: ");
    scanf("%d", &number);

    // Handle case when number is 0
    if (number == 0) {
        printf("Odd digits count: 0\n");
        printf("Even digits count: 1\n"); // Because 0 is considered even
    } else {
        printf("Odd digits count: %d\n", count_odd_digits(number));
        printf("Even digits count: %d\n", count_even_digits(number));
    }

    return 0;
}



