//Implement the Question 1 using a Linked List data structure.

#include <stdio.h>
#include <stdlib.h>

// Definition of the Node structure
struct Node {
    int data;            // To store a digit
    struct Node* next;   // Pointer to the next node
};

// Function to create a new node
struct Node* createNode(int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    if (!newNode) {
        printf("Memory allocation failed\n");
        exit(1);
    }
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}

// Function to insert a digit into the linked list
void insertDigit(struct Node** head, int data) {
    struct Node* newNode = createNode(data);
    newNode->next = *head;
    *head = newNode;
}

// Function to count odd digits recursively
int count_odd_digits(struct Node* head) {
    if (head == NULL) {
        return 0; // Base case: end of the list
    }

    int count = count_odd_digits(head->next); // Recursive call for the next node

    // Check if the current digit is odd
    if (head->data % 2 != 0) {
        return count + 1; // Increment count if it's odd
    } else {
        return count; // Return count as is if it's even
    }
}

// Function to count even digits recursively
int count_even_digits(struct Node* head) {
    if (head == NULL) {
        return 0; // Base case: end of the list
    }

    int count = count_even_digits(head->next); // Recursive call for the next node

    // Check if the current digit is even
    if (head->data % 2 == 0) {
        return count + 1; // Increment count if it's even
    } else {
        return count; // Return count as is if it's odd
    }
}

// Function to free the linked list
void freeList(struct Node* head) {
    struct Node* temp;
    while (head != NULL) {
        temp = head;
        head = head->next;
        free(temp);
    }
}

int main() {
    int number;
    struct Node* head = NULL;

    printf("Enter a number: ");
    scanf("%d", &number);

    // Break the number into digits and insert into the linked list
    if (number == 0) {
        insertDigit(&head, 0); // Handle the case where the number is 0
    } else {
        while (number > 0) {
            insertDigit(&head, number % 10); // Insert the last digit
            number /= 10; // Remove the last digit
        }
    }

    // Count odd and even digits
    printf("Odd digits count: %d\n", count_odd_digits(head));
    printf("Even digits count: %d\n", count_even_digits(head));

    // Free the linked list memory
    freeList(head);

    return 0;
}
