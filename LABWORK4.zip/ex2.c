#include <stdio.h>
#include <stdbool.h>

// Function to check if the array is a palindrome using recursion
bool isPalindrome(int arr[], int start, int end) {
    // Base case: If start crosses or equals end, it's a palindrome
    if (start >= end) {
        return true;
    }
    
    // If the current elements at both ends are not equal, it's not a palindrome
    if (arr[start] != arr[end]) {
        return false;
    }

    // Recursive call for the next set of elements
    return isPalindrome(arr, start + 1, end - 1);
}

int main() {
    int N;

    // Input the size of the array
    printf("Enter the size of the array: ");
    scanf("%d", &N);

    int arr[12345];

    // Input the elements of the array
    printf("Enter %d elements: ", N);
    for (int i = 0; i < N; i++) {
        scanf("%d", &arr[i]);
    }

    // Check if the array is a palindrome
    if (isPalindrome(arr, 0, N - 1)) {
        printf("The array is a palindrome.\n");
    } else {
        printf("The array is not a palindrome.\n");
    }

    return 0;
}
