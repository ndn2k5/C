#include <stdio.h>

// Function to calculate the digit sum using RECURSION
int digitSum(int n) {
    if (n == 0) {
        return 0;
    }
    return (n % 10) + digitSum(n / 10);
}

int main() {
    int N;

    // Input the number from the user
    printf("Enter a natural number: ");
    scanf("%d", &N);

    // Ensure the input is a natural number (positive integer)
    if (N < 0) {
        printf("Please enter a positive natural number.\n");
        return 1;
    }

    // Calculate and print the digit sum
    int result = digitSum(N);
    printf("The digit sum of %d is: %d\n", N, result);

    return 0;
}
