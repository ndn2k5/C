#include <stdio.h>

// Function to calculate the digit sum using iteration
int digitSum(int n) {
    int sum = 0;
    while (n > 0) {
        sum += n % 10; // n=666, 
        n /= 10;       // 6+6+6=18 delete the last digit
    }
    return sum;
}

int main() {
    int N;

    // Input the number from the user
    printf("Enter a natural number: ");
    scanf("%d", &N);

    // Ensure the input is a natural number (positive integer)
    if (N < 0) {
        printf("Please enter a positive natural number.\n");
        return 1;
    }

    // Calculate and print the digit sum
    int result = digitSum(N);
    printf("The digit sum of %d is: %d\n", N, result);

    return 0;
}
