//Write a pseudo-code by commenting in the file then implement a program in to enter a natural number n and verify whether n is sphenic. Calculate the complexit yof your program.
//Note: A sphenic number is a product of p*q*r where p, q, and r are three distinct
//prime numbers. Example: 30 = 2 * 3* 5; 42 = 2*3*7; 66 = 2*3*11

#include <stdio.h>
#include <math.h>

int sphenic(int n) {
    int res = 0;  // Count of distinct prime factors
    for (int i = 2; i <= sqrt(n); i++) {
        int cnt = 0;
        // Check how many times i divides n
        while (n % i == 0) {
            cnt++;
            n /= i;
        }
        // If a prime factor divides more than once, it can't be a sphenic number
        if (cnt > 1) return 0;
        // If it divides exactly once, increment the prime factor count
        if (cnt == 1) res++;
    }
    // If n is still greater than 1, it means n is a prime number and should be counted
    if (n > 1) res++;
    
    // A sphenic number must have exactly 3 distinct prime factors
    return res == 3;
}

int main() {
    int t;
    scanf("%d", &t); // Number of test cases
    for (int i = 0; i < t; i++) {
        int n;
        scanf("%d", &n);
        // Check if the number is sphenic
        if (sphenic(n)) {
            printf("%d is a sphenic number.\n", n);
        } else {
            printf("%d is not a sphenic number.\n", n);
        }
    }
    return 0;
}