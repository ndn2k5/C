//Complete this given function void findMax(int *max, int a), which assigns a valuea to max if a > max.

/*
FUNCTION findMax(max, a)
    IF a > *max
        *max = a   // Update the value pointed to by max with a
    END IF
END FUNCTION
*/


#include <stdio.h>
void findMax(int *max, int a) {
    if (a > *max) {
        *max = a;  // Assign the value of 'a' to 'max' if 'a' is greater than '*max'
    }
}

int main() {
    int max = 10;  // Initial maximum value
    int a = 15;    // Value to compare

    printf("Initial max: %d\n", max);

    findMax(&max, a);  // Pass the address of 'max' and the value of 'a'

    printf("New max: %d\n", max);

    return 0;
}
