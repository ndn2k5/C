//Write a pseudocode and implement a program in C to swap the first and last digits of a positive integer.


/*
INPUT: NUMBER OF DIGITS AND THE DIGITS.
OUTPUT: SWAP THE FIRST AND LAST DIGIT OF THE NUMBER.
BEGIN:
INT n
READ n
INT A[100000]
 FOR i=0 TO n-1 DO
    ENTER DIGIT
    READ A[i]
END FOR
PRINT A[n-1] -first digit
 FOR j=1 TO n-2 DO
    PRINT A[j] -the middle digits
END FOR
PRINT A[0] -last digit
END
*/

#include <stdio.h>
#include <math.h>

int swapFirstLastDigits(int num) {
    int numDigits = log10(num);  // Get number of digits - 1 (since log10 gives index)
    int firstDigit = num / pow(10, numDigits);  // Extract first digit
    int lastDigit = num % 10;  // Extract last digit

    // If there's only one digit, no need to swap
    if (numDigits == 0) {
        return num;
    }

    // Remove the first digit from the number
    int remainingNum = num % (int)pow(10, numDigits);
    remainingNum = remainingNum / 10;  // Remove the last digit
    
    // Form the new number by swapping
    int swappedNum = lastDigit * pow(10, numDigits) + remainingNum * 10 + firstDigit;

    return swappedNum;
}

int main() {
    int num, swappedNum;

    // Input the number
    printf("Enter a positive integer: ");
    scanf("%d", &num);

    // Swap the first and last digits
    swappedNum = swapFirstLastDigits(num);

    // Output the swapped number
    printf("Number after swapping first and last digits: %d\n", swappedNum);

    return 0;
}
