//Write a structure to represent complex numbers and complete operators: add and multiply.
/*
STRUCT Complex:
    real: float
    imag: float
END STRUCT

FUNCTION add(c1: Complex, c2: Complex) -> Complex:
    DECLARE result AS Complex
    result.real = c1.real + c2.real   // Add the real parts
    result.imag = c1.imag + c2.imag   // Add the imaginary parts
    RETURN result
END FUNCTION

FUNCTION multiply(c1: Complex, c2: Complex) -> Complex:
    DECLARE result AS Complex
    result.real = c1.real * c2.real - c1.imag * c2.imag  // Calculate real part
    result.imag = c1.real * c2.imag + c1.imag * c2.real  // Calculate imaginary part
    RETURN result
END FUNCTION

MAIN:
    DECLARE c1, c2, sum, product AS Complex
    PRINT "Enter real and imaginary parts of the first complex number"
    INPUT c1.real, c1.imag
    PRINT "Enter real and imaginary parts of the second complex number"
    INPUT c2.real, c2.imag

    sum = add(c1, c2)              // Call add function
    product = multiply(c1, c2)     // Call multiply function

    PRINT "Sum: ", sum.real, " + ", sum.imag, "i"
    PRINT "Product: ", product.real, " + ", product.imag, "i"
END MAIN

*/


#include <stdio.h>

// Structure to represent a complex number
typedef struct {
    float real;    // Real part
    float imag;    // Imaginary part
} Complex;

// Function to add two complex numbers
Complex add(Complex c1, Complex c2) {
    Complex result;
    result.real = c1.real + c2.real;
    result.imag = c1.imag + c2.imag;
    return result;
}

// Function to multiply two complex numbers
Complex multiply(Complex c1, Complex c2) {
    Complex result;
    result.real = c1.real * c2.real - c1.imag * c2.imag;  // Real part
    result.imag = c1.real * c2.imag + c1.imag * c2.real;  // Imaginary part
    return result;
}

int main() {
    Complex c1, c2, sum, product;

    // Input for first complex number
    printf("Enter the real and imaginary parts of the first complex number: ");
    scanf("%f %f", &c1.real, &c1.imag);

    // Input for second complex number
    printf("Enter the real and imaginary parts of the second complex number: ");
    scanf("%f %f", &c2.real, &c2.imag);

    // Adding the two complex numbers
    sum = add(c1, c2);

    // Multiplying the two complex numbers
    product = multiply(c1, c2);

    // Displaying the results
    printf("Sum: %.2f + %.2fi\n", sum.real, sum.imag);
    printf("Product: %.2f + %.2fi\n", product.real, product.imag);

    return 0;
}
