 //recursion 

 #include <stdio.h>

// Recursive function to count the number of odd and even digits in a number
void countDigits(int n, int* oddCount, int* evenCount) {
    if (n == 0) {
        return;
    }

    // Check if the last digit is odd or even
    if ((n % 10) % 2 == 0) {
        (*evenCount)++;
    } else {
        (*oddCount)++;
    }

    // Recursively call the function on the rest of the number
    countDigits(n / 10, oddCount, evenCount);
}

int main() {
    int n = 345872;
    int oddCount = 0;
    int evenCount = 0;

    countDigits(n, &oddCount, &evenCount);

    printf("Number of odd digits: %d\n", oddCount);
    printf("Number of even digits: %d\n", evenCount);

    return 0;
}