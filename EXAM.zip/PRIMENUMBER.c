#include <stdio.h>
#include <stdbool.h>
#include <math.h>

// Function to check if a number is prime
bool is_prime(int n)
{
    if (n <= 1)
    {
        return false;
    }
    for (int i = 2; i <= sqrt(n); i++)
    {
        if (n % i == 0)
        {
            return false;
        }
    }
    return true;
}
//complexity O(m)

// Function to check for twin primes in an array
void check_twin_primes(int arr[], int n)
{
    int found = 0;

    // Iterate through the array to find twin primes
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            int a = arr[i];
            int b = arr[j];
            if (is_prime(a) && is_prime(b) && abs(a - b) == 2)
            {
                printf("TWIN PRIMES: %d, %d\n", a, b);
                found++;
            }
        }
    }
    if (found == 0)
    {
        printf("No twin primes found\n");
    }
}
//Complexity is O(n^2)
int main()
{
    int arr[] = {3, 101, 96, 57, 41, 7, 65, 9, 13, 5, 79, 45, 30, 11, 43};
    int N = sizeof(arr) / sizeof(arr[0]);

    // Call the function to find twin primes
    check_twin_primes(arr, N);

    return 0;
}

//total complexity is O(n^2*m), BEST: O(n^2), avr: O(n^2*m), WORST: O(n^2*m) high