
#include <stdio.h>

// Function to find Pythagorean triples
void findPythagoreanTriples(int arr[], int n)
{
    int found = 0;

    // Iterate through all combinations of three numbers
    for (int i = 0; i < n - 2; i++)
    {
        for (int j = i + 1; j < n - 1; j++)
        {
            for (int k = j + 1; k < n; k++)
            {
                int a = arr[i];
                int b = arr[j];
                int c = arr[k];

                // Ensure a <= b <= c by sorting the values
                if (a > b)
                {
                    int temp = a;
                    a = b;
                    b = temp;
                }
                if (b > c)
                {
                    int temp = b;
                    b = c;
                    c = temp;
                }
                

                // Check if it's a Pythagorean triple
                if (a * a + b * b == c * c)
                {
                    printf("Pythagorean triple found: %d, %d, %d\n", a, b, c);
                    found = 1;
                }
            }
        }
    }

    // If no triples found
    if (!found)
    {
        printf("No Pythagorean triples found.\n");
    }
}

// Main function
int main()
{
    int arr[] = {4, 15, 28, 45, 40, 9, 53, 41, 8, 17, 3, 5, 1, 6, 8, 2, 1, 7, 8, 3, 1, 7, 8, 2, 13, 6, 9, 45, 2, 5, 8, 45};
    int N = sizeof(arr) / sizeof(arr[0]);

    // Call the function to find Pythagorean triples
    findPythagoreanTriples(arr, N);

    return 0;
}
