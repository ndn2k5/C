#include <stdio.h>

void findPythagoreanTriplesRec(int arr[], int n, int i, int j, int k, int *found)
{
    if (i >= n - 2)
    {
        if (!*found)
        {
            printf("No Pythagorean triples found.\n");
        }
        return;
    }

    if (j >= n - 1)
    {
        findPythagoreanTriplesRec(arr, n, i + 1, i + 2, i + 3, found);
        return;
    }

    if (k >= n)
    {
        findPythagoreanTriplesRec(arr, n, i, j + 1, j + 2, found);
        return;
    }

    int a = arr[i];
    int b = arr[j];
    int c = arr[k];

    // Ensure a <= b <= c by sorting the values
    if (a > b)
    {
        int temp = a;
        a = b;
        b = temp;
    }
    if (b > c)
    {
        int temp = b;
        b = c;
        c = temp;
    }
    if (a > b)
    {
        int temp = a;
        a = b;
        b = temp;
    }

    // Check if it's a Pythagorean triple
    if (a * a + b * b == c * c)
    {
        printf("Pythagorean triple found: %d, %d, %d\n", a, b, c);
        *found = 1;
    }

    findPythagoreanTriplesRec(arr, n, i, j, k + 1, found);
}

void findPythagoreanTriples(int arr[], int n)
{
    int found = 0;
    findPythagoreanTriplesRec(arr, n, 0, 1, 2, &found);
}

int main()
{
    int N;
    printf("Enter the number of elements: ");
    scanf("%d", &N);
    while (N < 5)
    {
        printf("REEnter the number of elements: ");
        scanf("%d", &N);
    }
    int arr[1234];

    // Initialize the array with random values between 1 and 20

    for (int i = 0; i < N; i++)
    {
        printf("enter element: %d ", i + 1);
        scanf("%d", &arr[i]); // Random values between 1 and 20
    }

    // Call the function to find Pythagorean triples
    findPythagoreanTriples(arr, N);

    return 0;
}
