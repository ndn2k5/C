#include <stdio.h>
#include <stdbool.h>

// Function to check if a number is prime
bool isPrime(int n)
{
    if (n <= 1)
        return false;
    if (n <= 3)
        return true;

    if (n % 2 == 0 || n % 3 == 0)
        return false;

    for (int i = 5; i * i <= n; i = i + 6)
        if (n % i == 0 || n % (i + 2) == 0)
            return false;

    return true;
}

// Function to find sphenic numbers
void findSphenic(int arr[], int n)
{
    for (int i = 0; i < n; i++)
    {
        int count = 0;
        for (int j = 2; j * j <= arr[i]; j++)
        {
            if (arr[i] % j == 0)
            {
                if (isPrime(j))
                    count++;
                if (arr[i] / j != j && isPrime(arr[i] / j))
                    count++;
            }
        }
        if (count == 3)
            printf("%d is a sphenic number.\n", arr[i]);
    }
}

int main()
{
    int arr[] = {30, 11, 12, 42};
    int n = sizeof(arr) / sizeof(arr[0]);
    findSphenic(arr, n);
    return 0;
}