#include <iostream>
using namespace std;

// ===========
// PSEUDO CODE
// ===========

// def condition(a: int, b: int, res: int) -> bool:
//     return a*a + b*b == res*res

// def loop(arr: list, ind_a: int, ind_b: int, ind_c: int, arr_length: int) -> None:
//     a = arr[ind_a]
//     b = arr[ind_b]
//     c = arr[ind_c]
//     if condition(a, b, c) or condition(a, c, b) or condition(b, c, a):
//         print(a, b, c)
//     if ind_c < arr_length - 1:
//         loop(arr, ind_a, ind_b, ind_c + 1, arr_length)
//     elif ind_b < arr_length - 2:
//         loop(arr, ind_a, ind_b + 1, ind_b + 2, arr_length)
//     elif ind_a < arr_length - 3:
//         loop(arr, ind_a + 1, ind_a + 2, ind_a + 3, arr_length)

bool condition(int a, int b, int result) {
    if (a*a + b*b == result*result) {
        return true;
    }
    return false;
}

void loop(int *array, int ind_a, int ind_b, int ind_c, int length) {
    int a = array[ind_a];
    int b = array[ind_b];
    int c = array[ind_c];
    if ((condition(a, b, c) == 1) || (condition(b, c, a) == 1) || (condition(c, a, b) == 1)) {
        cout << a << " " << b << " " << c << endl;
    }
    if (ind_c < length - 1) {
        loop(array, ind_a, ind_b, ind_c + 1, length);
    } else if (ind_b < length - 2) {
        loop(array, ind_a, ind_b + 1, ind_b + 2, length);
    } else if (ind_a < length - 3) {
        loop(array, ind_a + 1, ind_a + 2, ind_a + 3, length);
    }
}
// T(n) = O(n^3)

int main()
{
  int arr[] = {4, 15, 28, 45, 40, 9, 53, 41, 8, 17, 3, 5, 1, 6, 8, 2, 1, 7, 8, 3, 1, 7, 8, 2, 13, 6, 9, 45, 2, 5, 8, 45};
  int arr_length = sizeof(arr) / sizeof(arr[0]);
  loop(arr, 0, 1, 2, arr_length);
}
// T(n) = O(n^3)