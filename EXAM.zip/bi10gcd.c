#include <stdio.h>
#include <stdbool.h>

/*

INPUT: ARRAY 
OUTPUT: coprime pairs
BEGIN:
function gcdcheck(a,b)
    if a>b
        swap a and b
    for i = a to 2
        if a is divisible by i and b is divisible by i
            return i
    return 1
end function

function comprime check (array,length)
    found = 0
    for i = 0 to length-1
        for j = i+1 to length
            a = array[i]
            b = array[j]
            if gcdcheck(a,b) == 1
                print coprime pairs a,b
                found = 1
    if found == 0
        print "No coprime pairs found"
end function

input: array 
len array= size of array/ size of array 0
call function coprimecheck(array,len array)
END
*/




int gcdcheck(int a,int b){
    if (a>b){ //To make sure that m is the smaller number
        int temp = a;
        a = b;
        b = temp;
    }
    //T(n)=
    for (int i = a;i>1;i--){
        if (a%i==0 && b%i==0){//divisible by both
            return i;
        }
    }
    return 1;
    //complexity is 
}   




void coprimecheck(int arr[],int n){
    int found = 0;
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            int a = arr[i];
            int b = arr[j];
            if (gcdcheck(a,b)==1)
            {
                printf("Coprime pair: %d, %d\n", a, b);
                found=1;
            }
        }
    }
    if (found == 0)
    {
        printf("No coprime pairs found\n");
    }
}


int main(){
    int arr[]={2,10,27,13,90,45,5,26,49,50};
    int n = sizeof(arr) / sizeof(arr[0]);
    coprimecheck(arr,n);
    return 0;
}