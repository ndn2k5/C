/*
Write pseudo code using Recursion to find all Pythagorean triplets,
then write a program in C/C++ to complete your proposed algorithm in the pseudo-code.
*/

#include <stdio.h>
#include <stdbool.h>

// Function to check if a, b, and result form a Pythagorean triple
bool condition(int a, int b, int result) {
    return (a * a + b * b == result * result);
}

// Recursive function to iterate through all triples in the array
void loop(int *array, int ind_a, int ind_b, int ind_c, int length) {
    int a = array[ind_a];
    int b = array[ind_b];
    int c = array[ind_c];

    // Check if the current triple forms a Pythagorean triplet in any order
    if (condition(a, b, c) || condition(b, c, a) || condition(c, a, b)) {
        printf("%d %d %d\n", a, b, c);
    }

    // Recur for different combinations of indices
    if (ind_c < length - 1) {
        loop(array, ind_a, ind_b, ind_c + 1, length);
        } else if (ind_b < length - 2) {
        loop(array, ind_a, ind_b + 1, ind_b + 2, length);
            } else if (ind_a < length - 3) {
                 loop(array, ind_a + 1, ind_a + 2, ind_a + 3, length);
                    }
}   

int main() {
    int arr[] = {4, 15, 28, 45, 40, 9, 53, 41, 8, 17, 3, 5};
    int arr_length = sizeof(arr) / sizeof(arr[0]);

    // Call the loop function to find and print all Pythagorean triples
    loop(arr, 0, 1, 2, arr_length);

    return 0;
}
