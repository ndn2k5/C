#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define STACK_SIZE 3

// Definition of the Node structure
struct Node {
    int data;
    struct Node *next;
};

// Function to create a new node
struct Node *createNode(int data) {
    struct Node *newNode = (struct Node *)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        printf("Memory allocation failed\n");
        exit(1);
    }
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}

// Function to insert a new node at the end of the linked list
void insertNode(struct Node **head, int data) {
    struct Node *newNode = createNode(data);
    if (*head == NULL) {
        *head = newNode;
    } else {
        struct Node *temp = *head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = newNode;
    }
}

// Function to push an element onto the stack
void push(struct Node **stack, int data, int *size) {
    if (*size >= STACK_SIZE) {
        printf("Stack overflow\n");
        return;
    }
    struct Node *newNode = createNode(data);
    newNode->next = *stack;
    *stack = newNode;
    (*size)++;
}

// Function to pop an element from the stack
int pop(struct Node **stack, int *size) {
    if (*stack == NULL) {
        printf("Stack underflow\n");
        return -1;
    }
    struct Node *temp = *stack;
    int data = temp->data;
    *stack = (*stack)->next;
    free(temp);
    (*size)--;
    return data;
}

// Function to check if a number is prime
bool isPrime(int num) {
    if (num <= 1) return false;
    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0) return false;
    }
    return true;
}

// Function to find and push prime factors of a sphenic number onto the stack
void findAndPushPrimes(struct Node **stack, int sphenicNumber, int *size) {
    int count = 0;
    for (int i = 2; i <= sphenicNumber && count < STACK_SIZE; i++) {
        if (sphenicNumber % i == 0 && isPrime(i)) {
            push(stack, i, size);
            count++;
            sphenicNumber /= i;
        }
    }
    if (count != STACK_SIZE || sphenicNumber != 1) {
        printf("The number is not a sphenic number or has more than 3 prime factors.\n");
        while (*size > 0) {
            pop(stack, size);
        }
    }
}

// Function to display the stack
void displayStack(struct Node *stack) {
    if (stack == NULL) {
        printf("Stack is empty\n");
        return;
    }
    printf("Prime factors in the stack: ");
    while (stack != NULL) {
        printf("%d ", stack->data);
        stack = stack->next;
    }
    printf("\n");
}

int main() {
    struct Node *stack = NULL;
    int stackSize = 0;

    int sphenicNumber;
    printf("Enter a sphenic number: ");
    scanf("%d", &sphenicNumber);

    findAndPushPrimes(&stack, sphenicNumber, &stackSize);

    displayStack(stack);

    return 0;
}
